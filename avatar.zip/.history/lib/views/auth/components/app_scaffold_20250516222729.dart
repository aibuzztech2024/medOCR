import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppScaffold extends StatelessWidget {
  const AppScaffold({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            right: -50,
            bottom: 0,
            child: Container(
              height: 175,
              width: 175,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.theme.primaryColor.withOpacity(.1),
              ),
            ),
          ),
          Positioned(
            right: 130,
            bottom: 20,
            child: Container(
              height: 80,
              width: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.theme.colorScheme.secondary.withOpacity(.1),
              ),
            ),
          ),
          Positioned(
            right: 250,
            bottom: 0,
            child: Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.amber.withOpacity(.1),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
