import 'package:get/get.dart';
import 'role_model.dart'; // If Role is in a separate file

class SelectRoleController extends GetxController {
  final roles = <Role>[
    Role(
      role: 'customer',
      title: 'I\'m a Customer',
      caption: 'I Want To Buy Medicine Or Use Health Services',
    ),
    Role(
      role: 'pharmacy',
      title: 'I\'m a Pharmacy',
      caption: 'I Want To Manage and Sell Medicines',
    ),
    Role(
      role: 'client',
      title: 'I\'m a Client',
      caption: 'I Want To Register My Business On The Platform',
    ),
  ];

  final selectedIndex = (-1).obs;
}

class Role {
  final String role;
  final String title;
  final String caption;

  Role({required this.role, required this.title, required this.caption});
}
