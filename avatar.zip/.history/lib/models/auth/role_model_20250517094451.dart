class Role {
  final String role;
  final String title;
  final String caption;

  Role({required this.role, required this.title, required this.caption});
}
