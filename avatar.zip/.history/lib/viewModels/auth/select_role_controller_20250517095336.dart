import 'package:avatar/models/auth/role_model.dart';
import 'package:get/get.dart';

/// Controller used for managing the role selection logic in the UI.
///
/// This controller follows the GetX state management pattern and is placed in the
/// `ViewModels` layer of the MVVM architecture. It provides a list of available roles
/// and tracks which role is currently selected.
class SelectRoleController extends GetxController {
  /// List of predefined roles available for selection.
  ///
  /// Each [Role] contains a `role` identifier, a user-facing `title`, and a `caption`
  /// that describes the role's purpose.
  final roles = <Role>[
    Role(
      role: 'customer',
      title: 'I\'m a Customer',
      caption: 'I Want To Buy Medicine Or Use Health Services',
    ),
    Role(
      role: 'pharmacy',
      title: 'I\'m a Pharmacy',
      caption: 'I Want To Manage and Sell Medicines',
    ),
    Role(
      role: 'client',
      title: 'I\'m a Client',
      caption: 'I Want To Register My Business On The Platform',
    ),
  ];

  /// Observable index that represents the currently selected role.
  ///
  /// Default value is `-1`, meaning no role is selected initially.
  final selectedRoleIndex = (-1).obs;

  /// Updates the selected role index.
  ///
  /// This method is typically called when the user taps on a role option.
  ///
  /// [index] - the index of the selected role in the [roles] list.
  void updateRole(int index) {
    selectedRoleIndex.value = index;
  }
}
