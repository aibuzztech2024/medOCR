class ImagePaths {
  /// [Login/Register] header image
  static const String loginRegisterHeaderImage =
      '/assets/images/register_image.png';
}
