import 'package:avatar/core/utils/methods/country_picker.dart';
import 'package:avatar/core/widgets/app_button.dart';
import 'package:avatar/core/widgets/app_text.dart';
import 'package:avatar/core/widgets/height_box.dart';
import 'package:avatar/core/widgets/width_box.dart';
import 'package:avatar/viewModels/auth/register/register_controller.dart';
import 'package:avatar/views/auth/widget/input_field.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class BasicInfo extends StatelessWidget {
  /// On continue proceed to desired step
  final VoidCallback onContinue;
  const BasicInfo({super.key, required this.onContinue});

  @override
  Widget build(BuildContext context) {
    // Check if this controller is already present in memory,
    // if so, then find it else put it
    final registerController =
        Get.isRegistered<RegisterController>()
            ? Get.find<RegisterController>()
            : Get.put(RegisterController());
    return Column(
      children: [
        // Email field
        InputField(
          hintText: 'Email',
          controller: registerController.emailController,
        ),
        HeightBox(16),
        // Country Picker and Mobile Number field
        Row(
          children: [
            // Country picker to get country phone code
            AppButton(
              type: ButtonType.outlined,
              onPressed: () {
                // Shows country picker
                countryPicker(
                  context,
                  // Invokes select country method and updates it
                  onSelect: registerController.selectCountry,
                );
              },
              // Adds padding to flag and dropdown icon
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                // Selected country flag and dropdown icon
                child: Row(
                  children: [
                    // Selected Country flag
                    Obx(() {
                      var code = registerController.countryNameCode.value;
                      return SizedBox(
                        // Height of flag
                        height: 30,
                        // Width of flag
                        width: 45,
                        // Flag
                        child: SvgPicture.network(
                          'https://flagcdn.com/${code.toLowerCase()}.svg',
                          // If fails to fetch flag
                          errorBuilder: (_, __, ___) => AppText.heading(code),
                        ),
                      );
                    }),
                    WidthBox(5),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: context.theme.primaryColor,
                      size: 30,
                    ),
                  ],
                ),
              ),
            ),
            WidthBox(12),
            Expanded(
              flex: 1,
              child: InputField(
                hintText: 'Enter Phone No',
                controller: TextEditingController(),
              ),
            ),
          ],
        ),
        HeightBox(20),
        AppButton(
          width: double.infinity,
          type: ButtonType.filled,
          text: 'Send OTP',
          onPressed: registerController.sendOtp,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            AppText.caption('Didn\'t Receive Code? '),
            AppButton(
              type: ButtonType.text,
              onPressed: registerController.resendOtp,
              child: AppText.caption(
                'Resend',
                color: context.theme.primaryColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        HeightBox(16),
        InputField(
          hintText: 'Enter OTP',
          controller: registerController.otpController,
        ),
        HeightBox(16),
        AppButton(
          width: double.infinity,
          type: ButtonType.filled,
          text: 'Continue',
          onPressed: onContinue,
        ),
      ],
    );
  }
}
