import 'package:avatar/core/utils/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get_utils/get_utils.dart';

class DividerWithText extends StatelessWidget {
  final String middleText;
  const DividerWithText(this.middleText, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Divider(color: context.theme.primaryColor, height: 1)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 11),
          child: AppText.body(middleText, color: context.theme.primaryColor),
        ),
        Expanded(child: Divider(color: context.theme.primaryColor, height: 1)),
      ],
    );
  }
}
