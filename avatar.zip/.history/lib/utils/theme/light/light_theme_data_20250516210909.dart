import 'package:flutter/material.dart';

/// This file contains [LightThemeData]
final ThemeData lightThemeData = ThemeData(
  brightness: Brightness.light,
  primaryColor: const Color(0xFF1A4EAA), // Dark Blue for primary action
  scaffoldBackgroundColor: Colors.white,
  fontFamily: 'Roboto', // Use a modern sans-serif font
  textTheme: const TextTheme(
    titleLarge: TextStyle(
      fontSize: 22.0,
      fontWeight: FontWeight.bold,
      color: Color(0xFF1A4EAA),
    ),
    titleMedium: TextStyle(fontSize: 16.0, color: Colors.black54),
    bodyMedium: TextStyle(fontSize: 14.0, color: Colors.black87),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: Color(0xFFF8F9FB), // Light gray background
    contentPadding: const EdgeInsets.symmetric(
      vertical: 18.0,
      horizontal: 16.0,
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12.0),
      borderSide: const BorderSide(color: Color(0xFFDCE0E5)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12.0),
      borderSide: const BorderSide(color: Color(0xFF1A4EAA), width: 2),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12.0),
      borderSide: const BorderSide(color: Color(0xFFDCE0E5)),
    ),
    hintStyle: const TextStyle(color: Colors.black45),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFF1A4EAA), // Primary blue
      foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      textStyle: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
    ),
  ),
  iconTheme: const IconThemeData(color: Color(0xFF1A4EAA), size: 24),
);
