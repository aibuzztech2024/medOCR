import 'package:avatar/core/themes/light/light_theme_colors.dart';
import 'package:flutter/material.dart';

/// This file contains [lightThemeData] configured using [LightThemeColors]
final ThemeData lightThemeData = ThemeData(
  brightness: Brightness.light,
  primaryColor: LightThemeColors.primary,
  scaffoldBackgroundColor: LightThemeColors.scaffoldBackground,

  textTheme: const TextTheme(
    titleLarge: TextStyle(
      fontSize: 22.0,
      fontWeight: FontWeight.bold,
      color: LightThemeColors.titleText,
    ),
    titleMedium: TextStyle(
      fontSize: 16.0,
      color: LightThemeColors.subtitleText,
    ),
    bodyMedium: TextStyle(fontSize: 14.0, color: LightThemeColors.bodyText),
  ),

  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: LightThemeColors.inputFill,
    contentPadding: const EdgeInsets.symmetric(
      vertical: 18.0,
      horizontal: 16.0,
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12.0),
      borderSide: const BorderSide(color: LightThemeColors.inputBorder),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12.0),
      borderSide: const BorderSide(color: LightThemeColors.primary, width: 2),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12.0),
      borderSide: const BorderSide(color: LightThemeColors.inputBorder),
    ),
    hintStyle: const TextStyle(color: LightThemeColors.hintText),
  ),

  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: LightThemeColors.primary,
      foregroundColor: LightThemeColors.buttonText,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      textStyle: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
    ),
  ),

  iconTheme: const IconThemeData(color: LightThemeColors.icon, size: 24),
);
