import 'package:avatar/core/utils/methods/country_picker.dart';
import 'package:avatar/core/widgets/app_button.dart';
import 'package:avatar/core/widgets/app_text.dart';
import 'package:avatar/core/widgets/height_box.dart';
import 'package:avatar/core/widgets/width_box.dart';
import 'package:avatar/viewModels/auth/register/register_controller.dart';
import 'package:avatar/views/auth/widget/input_field.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class BasicInfo extends StatelessWidget {
  final VoidCallback onContinue;
  const BasicInfo({super.key, required this.onContinue});

  @override
  Widget build(BuildContext context) {
    final registerController =
        Get.isRegistered<RegisterController>()
            ? Get.find<RegisterController>()
            : Get.put(RegisterController());
    return Column(
      children: [
        InputField(
          hintText: 'Email',
          controller: registerController.emailController,
        ),
        HeightBox(16),
        Row(
          children: [
            AppButton(
              type: ButtonType.outlined,

              onPressed: () {
                countryPicker(
                  context,
                  onSelect: (Country val) {
                    registerController.countryNameCode.value = val.countryCode;
                    registerController.countryPhoneCode.value =
                        '+${val.phoneCode}';
                  },
                );
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  children: [
                    SizedBox(
                      height: 30,
                      width: 45,
                      child: SvgPicture.network(
                        'https://flagcdn.com/${registerController.countryNameCode.value.toLowerCase()}.svg',
                      ),
                    ),
                    WidthBox(5),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: context.theme.primaryColor,
                      size: 30,
                    ),
                  ],
                ),
              ),
            ),
            WidthBox(12),
            Expanded(
              flex: 1,
              child: InputField(
                hintText: 'Enter Phone No',
                controller: TextEditingController(),
              ),
            ),
          ],
        ),
        HeightBox(20),
        AppButton(
          width: double.infinity,
          type: ButtonType.filled,
          text: 'Send OTP',
          onPressed: () {},
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            AppText.caption('Didn\'t Receive Code? '),
            AppButton(
              type: ButtonType.text,
              child: AppText.caption(
                'Resend',
                color: context.theme.primaryColor,
                fontWeight: FontWeight.w500,
              ),
              onPressed: () {},
            ),
          ],
        ),
        HeightBox(16),
        InputField(hintText: 'Enter OTP', controller: TextEditingController()),
        HeightBox(16),
        AppButton(
          width: double.infinity,
          type: ButtonType.filled,
          text: 'Continue',
          onPressed: onContinue,
        ),
      ],
    );
  }
}
