import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppScaffold extends StatelessWidget {
  const AppScaffold({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    // Define relative sizes for circles based on screen width
    final largeCircleSize = size.width * 0.35; // ~35% of screen width
    final mediumCircleSize = size.width * 0.16; // ~16%
    final smallCircleSize = size.width * 0.10; // ~10%

    // Define relative positions (distance from right and bottom)
    final largeCircleRight = -largeCircleSize * 0.34;
    final largeCircleBottom = -0.3;

    final mediumCircleRight = size.width * 0.38;
    final mediumCircleBottom = size.height * 0.03;

    final smallCircleRight = size.width * 0.62;
    final smallCircleBottom = -size.height * 0.02;

    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            right: largeCircleRight,
            bottom: largeCircleBottom,
            child: Container(
              height: largeCircleSize,
              width: largeCircleSize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.theme.primaryColor.withOpacity(.1),
              ),
            ),
          ),
          Positioned(
            right: mediumCircleRight,
            bottom: mediumCircleBottom,
            child: Container(
              height: mediumCircleSize,
              width: mediumCircleSize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.theme.colorScheme.secondary.withOpacity(.1),
              ),
            ),
          ),
          Positioned(
            right: smallCircleRight,
            bottom: smallCircleBottom,
            child: Container(
              height: smallCircleSize,
              width: smallCircleSize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.amber.withOpacity(.1),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
