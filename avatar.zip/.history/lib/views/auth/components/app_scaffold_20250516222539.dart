import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppScaffold extends StatelessWidget {
  const AppScaffold({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            right: -70,
            bottom: 0,
            child: Container(
              height: 200,
              width: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.theme.primaryColor.withOpacity(.1),
              ),
            ),
          ),
          Positioned(
            right: 145,
            bottom: 20,
            child: Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.theme.colorScheme.secondary.withOpacity(.1),
              ),
            ),
          ),
          Positioned(
            right: 250,
            bottom: 0,
            child: Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.theme.colorScheme.onPrimary.withOpacity(.1),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
