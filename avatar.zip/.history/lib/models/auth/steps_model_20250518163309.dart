import 'package:flutter/material.dart';

/// A model class representing steps to register.
///
/// Each step contains a title, and an icon
class StepModel {
  /// Title to explain what this step does
  final String title;

  /// Icon to show visual of that step
  final Icon icon;

  StepModel({required this.title, required this.icon});
}
