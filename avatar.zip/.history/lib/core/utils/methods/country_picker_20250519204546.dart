import 'package:avatar/core/widgets/app_text.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';

countryPicker(
  BuildContext context, {
  required Function(Country value) onSelect,
}) {
  showCountryPicker(
    context: context,

    customFlagBuilder: (country) {
      return SizedBox(
        height: 24,
        width: 32,
        child: AppText.heading(country.flagEmoji),
      );
    },
    onSelect: onSelect,
  );
}
