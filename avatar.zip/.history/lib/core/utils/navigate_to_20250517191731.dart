import 'package:flutter/material.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/utils.dart';

// This util method is created to ensure default duration and transition can be updated from single point

void navigateTo(Widget page, {Duration? duration, Transition? transition}) {
  Get.to(
    () => page,
    duration: duration ?? Durations.medium1,
    transition: transition ?? Transition.rightToLeftWithFade,
  );
}
