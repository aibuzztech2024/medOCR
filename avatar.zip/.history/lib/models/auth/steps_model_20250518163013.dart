class StepModel {
  final String title;
  final Icon icon;

  StepModel({required this.title, required this.icon});
}
