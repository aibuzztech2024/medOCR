import 'package:avatar/core/utils/app_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get_utils/get_utils.dart';

/// Defines the type of button: either a filled [ElevatedButton]
/// or an outlined [OutlinedButton].
enum ButtonType { filled, outlined }

/// A customizable button widget that supports both filled and outlined styles.
///
/// Includes options for padding, colors, border radius, and optional
/// Hero animations for text transitions between screens.
class AppButton extends StatelessWidget {
  /// The type of button to display: [ButtonType.filled] or [ButtonType.outlined].
  final ButtonType type;

  /// The callback triggered when the button is pressed.
  final VoidCallback? onPressed;

  /// The text displayed inside the button.
  final String text;

  /// The background color of the button (for filled) or border/text color (for outlined).
  final Color? color;

  /// The color of the text.
  final Color? textColor;

  /// The border radius of the button's corners.
  final double? borderRadius;

  /// Padding around the button's content.
  final EdgeInsetsGeometry? padding;

  /// If true, wraps the button text with a [Hero] widget for shared element transition.
  ///
  /// Requires [animateTag] to be non-null.
  final bool shouldAnimate;

  /// The tag used for the [Hero] animation.
  ///
  /// Must be provided if [shouldAnimate] is true, else an assertion error will be thrown.
  final String? animateTag;

  /// Creates an [AppButton] with configurable appearance and optional animation.
  ///
  /// Throws an [AssertionError] if [shouldAnimate] is true but [animateTag] is null.
  const AppButton({
    super.key,
    required this.type,
    required this.text,
    this.onPressed,
    this.color,
    this.textColor,
    this.borderRadius,
    this.padding,
    this.shouldAnimate = false,
    this.animateTag,
  }) : assert(
         shouldAnimate == false ||
             (shouldAnimate == true && animateTag != null),
         'If shouldAnimate is true, animateTag must be provided',
       );

  @override
  Widget build(BuildContext context) {
    final borderRadiusValue = borderRadius ?? 12.0;
    final buttonPadding = padding ?? const EdgeInsets.symmetric(vertical: 16.0);

    /// Helper method to optionally wrap text with Hero animation.
    Widget animatedTextWidget(Widget child) {
      return shouldAnimate
          ? Hero(
            tag: animateTag!,
            child: Material(type: MaterialType.transparency, child: child),
          )
          : child;
    }

    switch (type) {
      case ButtonType.filled:
        return ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: color ?? Theme.of(context).primaryColor,
            foregroundColor: textColor ?? Colors.white,
            padding: buttonPadding,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(borderRadiusValue),
            ),
          ),
          child: animatedTextWidget(
            Text(
              text,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ),
        );

      case ButtonType.outlined:
        return OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            foregroundColor: color ?? Theme.of(context).primaryColor,
            padding: buttonPadding,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(borderRadiusValue),
            ),
            side: BorderSide(
              color: color ?? Theme.of(context).primaryColor,
              width: 1.5,
            ),
          ),
          child: animatedTextWidget(
            AppText.heading(
              text,
              color: context.theme.primaryColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        );
    }
  }
}
