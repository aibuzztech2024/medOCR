import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/utils.dart';

void navigateTo(Widget page, {Duration? duration, Transition? transition}) {
  Get.to(
    () => page,
    duration: duration ?? Durations.medium1,
    transition: transition ?? Transition.rightToLeftWithFade,
  );
}
