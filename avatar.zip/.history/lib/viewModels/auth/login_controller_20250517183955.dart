import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  RxBool isObscured = true.obs;
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  // TODO: Implement login functionality
  void login() {
    Get.printInfo(info: usernameController.text);
    Get.printInfo(info: passwordController.text);
  }
}
