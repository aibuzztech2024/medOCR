import 'package:avatar/core/utils/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get_utils/get_utils.dart';

/// Button style types: [filled] for solid background, [outlined] for bordered style.
enum ButtonType { filled, outlined }

/// A customizable app-wide button supporting filled and outlined styles.
///
/// You must provide **either** [text] or a custom [child] widget — not both.
///
/// Example usage:
/// ```dart
/// // Filled button with text
/// AppButton(
///   type: ButtonType.filled,
///   text: 'Login',
///   onPressed: () {},
/// );
///
/// // Outlined button with custom child (e.g., an icon + text)
/// AppButton(
///   type: ButtonType.outlined,
///   child: Row(
///     children: [Icon(Icons.add), Text('Add')],
///   ),
///   onPressed: () {},
/// );
/// ```
class AppButton extends StatelessWidget {
  /// Defines the visual style of the button: filled or outlined.
  final ButtonType type;

  /// Callback when the button is pressed. If null, the button will be disabled.
  final VoidCallback? onPressed;

  /// Optional text to display on the button. Required if [child] is not provided.
  final String? text;

  /// Optional custom widget to display inside the button.
  /// Required if [text] is not provided.
  final Widget? child;

  /// Background color for filled button or border/text color for outlined.
  final Color? color;

  /// Text color for the filled button. Ignored for outlined buttons.
  final Color? textColor;

  /// The border radius of the button. Defaults to `12.0`.
  final double? borderRadius;

  /// Padding inside the button. Defaults to `EdgeInsets.symmetric(vertical: 16.0)`.
  final EdgeInsetsGeometry? padding;

  /// Creates a styled button.
  ///
  /// Either [text] or [child] must be provided (not both).
  const AppButton({
    super.key,
    required this.type,
    this.text,
    this.child,
    this.onPressed,
    this.color,
    this.textColor,
    this.borderRadius,
    this.padding,
  }) : assert(
         (text != null && child == null) || (text == null && child != null),
         'You must provide either `text` or `child`, not both or neither.',
       );

  @override
  Widget build(BuildContext context) {
    final borderRadiusValue = borderRadius ?? 12.0;
    final buttonPadding = padding ?? const EdgeInsets.symmetric(vertical: 20);

    // Determine the button content
    Widget content;
    if (text != null) {
      content =
          type == ButtonType.outlined
              ? AppText.heading(
                text!,
                color: context.theme.primaryColor,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              )
              : AppText(
                text!,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: textColor ?? Colors.white,
                ),
              );
    } else {
      content = child!;
    }

    // Return styled button based on type
    switch (type) {
      case ButtonType.filled:
        return ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: color ?? Theme.of(context).primaryColor,
            foregroundColor: textColor ?? Colors.white,
            padding: buttonPadding,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(borderRadiusValue),
            ),
          ),
          child: content,
        );

      case ButtonType.outlined:
        return OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            foregroundColor: color ?? Theme.of(context).primaryColor,
            padding: buttonPadding,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(borderRadiusValue),
            ),
            side: BorderSide(
              color: color ?? Theme.of(context).primaryColor,
              width: 1.5,
            ),
          ),
          child: content,
        );
    }
  }
}
