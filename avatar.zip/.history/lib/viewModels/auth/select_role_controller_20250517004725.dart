import 'package:get/get.dart';

class SelectRoleController extends GetxController {
  List<Map<String, String>> roles = [
    {
      'role': 'customer',
      'title': 'I\'m a Customer',
      'caption': 'I Want To Buy Medicine Or Use Health Services',
    },
    {
      'role': 'pharmacy',
      'title': 'I\'m a Pharmacy',
      'caption': 'I Want To Manage and Sell Medicines',
    },
    {
      'role': 'client',
      'title': 'I\'m a Client',
      'caption': 'I Want To Register My Business On The Platform',
    },
  ];
}
