import 'package:country_picker/country_picker.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class RegisterController extends GetxController {
  /// INFO: For basic info, it is common for all type of register
  var emailController = TextEditingController();
  var countryPhoneCode = '+91'.obs;
  var countryNameCode = 'IN'.obs;
  var phoneNumberController = TextEditingController();
  var otpController = TextEditingController();

  sendOtp() {
    Get.log('Send otp to ${countryPhoneCode + phoneNumberController.text}');
  }

  resendOtp() {
    Get.log('Resend Otp');
  }

  selectCountry(Country country) {
    countryNameCode.value = country.countryCode;
    countryPhoneCode.value = '+${country.phoneCode}';
  }
}
