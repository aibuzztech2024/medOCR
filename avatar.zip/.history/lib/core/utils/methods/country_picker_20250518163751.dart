import 'package:avatar/core/widgets/app_text.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';

countryPicker(BuildContext context, Function(Country) onSelect) {
  showCountryPicker(
    context: context,
    customFlagBuilder: (country) {
      return SizedBox(
        height: 24,
        width: 32,
        child: SvgPicture.network(
          'https://flagcdn.com/${country.countryCode.toLowerCase()}.svg',
          errorBuilder: (_, __, ___) {
            return AppText.heading(country.countryCode);
          },
        ),
      );
    },
    onSelect: onSelect,
  );
}
