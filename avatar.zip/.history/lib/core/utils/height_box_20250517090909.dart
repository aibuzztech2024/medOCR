import 'package:flutter/material.dart';

/// A widget that creates a height box with a specified height.
class HeightBox extends StatelessWidget {
  final double height;
  const HeightBox(this.height, {super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(height: height);
  }
}
