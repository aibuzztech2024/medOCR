import 'package:get/get.dart';

class SelectRoleController extends GetxController {
  var roles = {
    'role': 'customer',
    'title': 'I\'m a Customer',
    'service': 'I Want To Buy Medicine Or Use Health Services',
  };
}
