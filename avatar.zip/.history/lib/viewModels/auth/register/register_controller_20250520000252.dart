import 'package:country_picker/country_picker.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class RegisterController extends GetxController {
  /// INFO: For basic info, it is common for all type of register
  var emailController = TextEditingController();
  var country = Country.parse('IN').obs;
  var phoneNumberController = TextEditingController();
  var otpController = TextEditingController();

  /// INFO: For tracking steps of form
  var activeStep = 0.obs;

  sendOtp() {
    Get.log(
      'Send otp to ${country.value.phoneCode + phoneNumberController.text}',
    );
  }

  resendOtp() {
    Get.log(
      'Resend otp to ${country.value.phoneCode + phoneNumberController.text}',
    );
  }
}
