import 'package:flutter/material.dart';

class AppButton extends StatelessWidget {
  const AppButton({super.key});

  @override
  Widget build(BuildContext context) {
    switch (expression) {
      case value:
        break;
      default:
    }
  }
}

enum button_type { primary, secondary, tertiary }
