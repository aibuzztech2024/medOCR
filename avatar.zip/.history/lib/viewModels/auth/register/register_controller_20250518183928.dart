import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class RegisterController extends GetxController {
  /// INFO: For basic info, it is common for all type of register
  var emailController = TextEditingController();
  var countryCode = '+91'.obs;
  var phoneNumberController = TextEditingController();
  var otpController = TextEditingController();
}
