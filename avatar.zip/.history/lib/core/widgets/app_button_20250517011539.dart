import 'package:avatar/core/utils/app_text.dart';
import 'package:flutter/material.dart';

enum ButtonType { filled, outlined }

class AppButton extends StatelessWidget {
  final ButtonType type;
  final VoidCallback? onPressed;
  final String text;
  final Color? color;
  final Color? textColor;
  final double? borderRadius;
  final EdgeInsetsGeometry? padding;

  const AppButton({
    super.key,
    required this.type,
    required this.text,
    this.onPressed,
    this.color,
    this.textColor,
    this.borderRadius,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    final borderRadiusValue = borderRadius ?? 12.0;
    final buttonPadding = padding ?? const EdgeInsets.symmetric(vertical: 16.0);

    switch (type) {
      case ButtonType.filled:
        return ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: color ?? Theme.of(context).primaryColor,
            foregroundColor: textColor ?? Colors.white,
            padding: buttonPadding,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(borderRadiusValue),
            ),
          ),
          child: Text(
            text,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        );

      case ButtonType.outlined:
        return OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            foregroundColor: color ?? Theme.of(context).primaryColor,
            padding: buttonPadding,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(borderRadiusValue),
            ),
            side: BorderSide(
              color: color ?? Theme.of(context).primaryColor,
              width: 1.5,
            ),
          ),
          child: AppText.heading(text),
        );
    }
  }
}
