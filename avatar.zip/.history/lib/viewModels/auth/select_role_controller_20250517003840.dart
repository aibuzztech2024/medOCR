import 'package:get/get.dart';

class SelectRoleController extends GetxController {
  Map<String, String> roles = {'role': 'I\'m a Customer'};
}
