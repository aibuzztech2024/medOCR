class ImagePaths {
  /// [Login/Register] header image
  static const String loginRegisterHeaderImage =
      '/assets/images/login_register_image.png';
}
