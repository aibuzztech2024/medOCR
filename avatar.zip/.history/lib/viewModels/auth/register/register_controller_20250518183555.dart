import 'package:get/get.dart';

class RegisterController extends GetxController {
  /// INFO: For basic info, it is common for all type of register
}
